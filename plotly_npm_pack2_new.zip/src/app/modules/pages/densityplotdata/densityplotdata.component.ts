import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-densityplotdata',
  templateUrl: './densityplotdata.component.html',
  styleUrls: ['./densityplotdata.component.scss']
})
export class DensityplotdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
