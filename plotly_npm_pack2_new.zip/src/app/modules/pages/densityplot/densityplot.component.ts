import { Component, OnInit } from '@angular/core';
var Plotly:any = require('plotly.js-dist');
import densityData from '../../../service/densityPlot.json'
@Component({
  selector: 'app-densityplot',
  templateUrl: './densityplot.component.html',
  styleUrls: ['./densityplot.component.scss']
})
export class DensityplotComponent implements OnInit {

  constructor() { }
  densityVal:any = [];
  ngOnInit(): void {
   // this.densityPlot();
 
   this.densityVal = densityData['data'];
 
   this.converXvalues(this.densityVal);

   
  }

//   densityPlot(){
//     var x = [0.5,10,1.5,20,2.5,30,3.5,40,4.5,5,50,5.5,60,6.5,7,7.5];
//     // var y = [0.025,0.2,0.015]
//   // for (var i = 0; i < 500; i ++) {
// 	// x[i] = Math.random();
//   //  }
//    console.log('density plot==>',x)

//   var trace = {
//     x: x,
//    // y: y,
//     type: 'histogram',
//     marker: {
//       color: 'rgb(102, 153, 153)',
//    },
//   };
//   var data = [trace];
//   var layout = {
//     title:"Density Plot for: hotalcount5smile",
   
//     yaxis:{
//       range: [0,0.025],
//      title:"KDE",
  
//     },
//     xaxis:{
//      range: [0,250],
//       title:"",
    
//      }
// ,
//      updatemenus: [{
//       yanchor: 'top',
//       buttons: [{
//           method: 'update',
//           args: ['visible', [true, false, false, false]],
//           label: 'hotalcount5smile',
       
//         },
//         {
//           method: 'update',
//           args: ['visible', [false, true, false, false]],
//           label: 'Two',
         
//         }
//       ],
//       direction:"down",
//       pad:{
//         l: 0,
//         r: 40,
//         b: 0,
//         t: 0,
//       },
//     }]
//   };
//   Plotly.newPlot('dencity', data,layout);
//   }
hotalid:any = [];
max_rooms_capacity:any = [];
building_type: any = [];
location_type: any = [];
AvgDailyRate:any = [];
Compet_Occupancy:any = [];
Compet_AvgDailyRate: any = [];
PercentGovtNights:any = [];
PercentGroupNights:any = [];
PercentTransientNights:any = [];
PercentBusiness: any = [];
PercentLeisure: any = [];
hotelcount1mile: any = [];
hotelcount5mile: any = [];
rooms1mile:any = [];
rooms5mile: any = [];
loyalty_pct: any = [];
call_center_booking_pct: any = [];
travel_agency_booking_pct: any = [];
third_party_web_bookings_pct:any = [];
hotel_to_hotel_bookings_pct: any = [];
direct_call_booking_pct:any = [];
direct_web_booking_pct: any = [];
Class: any = [];

converXvalues(densityArray:any){
  console.log('inside function',densityArray);
  densityArray.forEach((element,i) => {
    //console.log(element)
    this.hotalid.push(element.hotel_id);
    this.max_rooms_capacity.push(element.max_rooms_capacity)
    this.building_type.push(element.building_type)
    this.location_type.push(element.location_type)
    this.AvgDailyRate.push(element.AvgDailyRate)
    this.Compet_Occupancy.push(element.Compet_Occupancy)
    this.Compet_AvgDailyRate.push(element.Compet_AvgDailyRate)
    this.PercentGovtNights.push(element.PercentGovtNights)
    this.PercentTransientNights.push(element.PercentTransientNights)
    this.PercentBusiness.push(element.PercentBusiness)
    this.PercentLeisure.push(element.PercentLeisure)
    this.hotelcount1mile.push(element.hotelcount1mile)
    this.rooms1mile.push(element.rooms1mile)
    this.rooms5mile.push(element.rooms5mile)
    this.loyalty_pct.push(element.loyalty_pct)
    this.call_center_booking_pct.push(element.call_center_booking_pct)
    this.travel_agency_booking_pct.push(element.travel_agency_booking_pct)
    this.third_party_web_bookings_pct.push(element.third_party_web_bookings_pct)
    this.hotel_to_hotel_bookings_pct.push(element.hotel_to_hotel_bookings_pct)
    this.direct_call_booking_pct.push(element.direct_call_booking_pct)
    this.direct_web_booking_pct.push(element.direct_web_booking_pct)
    this.Class.push(element.Class)

  });

  this.densityPlotDropDown();
}

  densityPlotDropDown(){
    var trace1 = {
      x: this.hotalid,
   
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
     },
      name: 'Trace 1',
    }
    
    var trace2 = {
      x: this.max_rooms_capacity,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 2',
    }
    var trace3 = {
      x: this.building_type,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 3',
    }
    var trace4 = {
      x: this.location_type,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 4',
    }
    var trace5 = {
      x: this.AvgDailyRate,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 5',
    }
    var trace6 = {
      x: this.Compet_Occupancy,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 6',
    }
    var trace7 = {
      x: this.Compet_AvgDailyRate,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 7',
    }
    var trace8 = {
      x: this.PercentGovtNights,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 8',
    }
    var trace9 = {
      x: this.PercentTransientNights,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 9',
    }
    var trace10 = {
      x: this.PercentBusiness,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 10',
    }
    var trace11 = {
      x: this.PercentLeisure,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 11',
    }
    var trace12 = {
      x: this.hotelcount1mile,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 12',
    }
    var trace13 = {
      x: this.rooms1mile,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 13',
    }
    var trace14 = {
      x: this.rooms5mile,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 14',
    }
    var trace15 = {
      x: this.loyalty_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 15',
    }
    var trace16 = {
      x: this.call_center_booking_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 16',
    }
    var trace17 = {
      x: this.travel_agency_booking_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 17',
    }
    var trace18 = {
      x: this.third_party_web_bookings_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 18',
    }
    var trace19 = {
      x: this.hotel_to_hotel_bookings_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 19',
    }
    var trace20 = {
      x: this.direct_call_booking_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 20',
    }
    var trace21 = {
      x: this.direct_web_booking_pct,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 21',
    }
    var trace22 = {
      x: this.Class,
    
      type: 'histogram',
      marker: {
        color: 'rgb(102, 153, 153)',
       },
      name: 'Trace 22',
    }
    
    var frames = [{
        name: 'trace 1',
        data: [{
          x: trace1.x,
          marker: {
            color: trace1.marker.color,
           },
        }]
      },
      {
        name: 'trace 2',
        data: [{
          x: trace2.x,
          marker: {
            color: trace2.marker.color,
           },
        }]
      }
    ]
    //console.log(frames)
    var layout = {
      title:"Density Plot for: hotalcount5smile",
      yaxis: {
       // range: [0,0.025],
        title:"KDE",
      },
      xaxis: {
       // range: [0,250],
        title:"",
      },
      updatemenus: [{
        buttons: [{
            method: 'animate',
            args: [
              ['trace 1']
            ],
            label: 'One'
          },
          {
            method: 'animate',
            args: [
              ['trace 2']
            ],
            label: 'Two'
          }
        ],
        x :0.0,
      
        y :1.15,
        xanchor : 'left',
        direction:"right",
        pad:{
          l: 0,
          r: 0,
          b: 0,
          t: 0,
        },
      }]
    }
    
    Plotly.newPlot("dencityplot", [trace1], layout).then(function() {
      Plotly.addFrames('dencityplot', frames);
    });
  }


}
